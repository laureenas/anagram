# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.word_list import WordList  # noqa: E501
from swagger_server.test import BaseTestCase


class TestCorpusController(BaseTestCase):
    """CorpusController integration test stubs"""

    def test_words_delete(self):
        """Test case for words_delete

        Delete all words in the corpus.
        """
        response = self.client.open(
            '/api/v1//words',
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_words_post(self):
        """Test case for words_post

        Add English-language words to the corpus.
        """
        body = WordList()
        response = self.client.open(
            '/api/v1//words',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_words_word_delete(self):
        """Test case for words_word_delete

        Delete a single word from the corpus.
        """
        response = self.client.open(
            '/api/v1//words/word'.format(single_word='single_word_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
