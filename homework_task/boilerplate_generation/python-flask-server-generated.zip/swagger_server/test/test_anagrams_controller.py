# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.anagram_list import AnagramList  # noqa: E501
from swagger_server.test import BaseTestCase


class TestAnagramsController(BaseTestCase):
    """AnagramsController integration test stubs"""

    def test_anagrams_word_get(self):
        """Test case for anagrams_word_get

        Takes a JSON array of English-language words and adds them to the corpus.
        """
        response = self.client.open(
            '/api/v1//anagrams/word'.format(single_word='single_word_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
