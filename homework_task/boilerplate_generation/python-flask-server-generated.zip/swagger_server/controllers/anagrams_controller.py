import connexion
import six

from swagger_server.models.anagram_list import AnagramList  # noqa: E501
from swagger_server import util


def anagrams_word_get(single_word):  # noqa: E501
    """Takes a JSON array of English-language words and adds them to the corpus.

    Returns a JSON array of English-language words that are anagrams of the word passed in the URL.  # noqa: E501

    :param single_word: English languate word
    :type single_word: str

    :rtype: AnagramList
    """
    return 'do some magic!'
