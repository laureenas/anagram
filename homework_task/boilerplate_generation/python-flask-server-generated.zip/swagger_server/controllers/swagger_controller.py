import connexion
import six

from swagger_server import util


def swagger_json_get():  # noqa: E501
    """Show machine-readable API documentation.

    Swagger documentation of API endpoints. # noqa: E501


    :rtype: None
    """
    return 'do some magic!'
