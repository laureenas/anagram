import connexion
import six

from swagger_server.models.inline_response200 import InlineResponse200  # noqa: E501
from swagger_server import util


def version_get():  # noqa: E501
    """Return API version.

     # noqa: E501


    :rtype: InlineResponse200
    """
    return 'do some magic!'
