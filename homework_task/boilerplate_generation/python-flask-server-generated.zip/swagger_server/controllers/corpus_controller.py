import connexion
import six

from swagger_server.models.word_list import WordList  # noqa: E501
from swagger_server import util


def words_delete():  # noqa: E501
    """Delete all words in the corpus.

     # noqa: E501


    :rtype: Object
    """
    return 'do some magic!'


def words_post(body=None):  # noqa: E501
    """Add English-language words to the corpus.

    Takes a JSON array of English-language words and adds them to the corpus. # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: Object
    """
    if connexion.request.is_json:
        body = WordList.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def words_word_delete(single_word):  # noqa: E501
    """Delete a single word from the corpus.

     # noqa: E501

    :param single_word: English languate word
    :type single_word: str

    :rtype: Object
    """
    return 'do some magic!'
